// options.js - ChatGenius AI Settings Page (Refactored)

// SYNC: Backend API base URL - must match across all files (background.js, options.js)
const API_BASE_URL = 'https://chat.sopie.cc';

// SYNC: Daily usage limit for free tier - must match across all files
const DAILY_LIMIT = 20;

// Upgrade URL
const UPGRADE_URL = 'https://chatgenius.ai/#pricing';

// Chrome API compatibility layer for standalone preview
if (typeof chrome === 'undefined' || !chrome.storage) {
  const _mockStorage = {};
  const _mockGet = (storage) => (keys, cb) => {
    if (typeof keys === 'object' && !Array.isArray(keys)) {
      const result = Object.assign({}, keys);
      for (const key of Object.keys(keys)) {
        if (key in _mockStorage) result[key] = _mockStorage[key];
      }
      cb && cb(result);
    } else {
      cb && cb(_mockStorage);
    }
  };
  const _mockSet = (storage) => (data, cb) => {
    Object.assign(_mockStorage, data);
    cb && cb();
  };
  const _mockRemove = (storage) => (keys, cb) => {
    if (Array.isArray(keys)) keys.forEach(k => delete _mockStorage[k]);
    else delete _mockStorage[keys];
    cb && cb();
  };
  window.chrome = {
    storage: {
      sync: { get: _mockGet('sync'), set: _mockSet('sync'), remove: _mockRemove('sync') },
      local: { get: _mockGet('local'), set: _mockSet('local'), remove: _mockRemove('local') }
    },
    runtime: {
      sendMessage: (msg, cb) => {
        const p = Promise.resolve({ success: false, error: 'Preview not available outside extension' });
        if (typeof cb === 'function') p.then(cb);
        return p;
      },
      onMessage: { addListener: () => {} }
    },
    i18n: { getMessage: (key) => key, getUILanguage: () => 'en' }
  };
}

// ================================
// I18N
// ================================
const I18N = {
  en: {
    title: 'ChatGenius AI Settings',
    subtitle: 'Manage your AI personas, knowledge base and preferences',
    tabPersonas: 'AI Personas',
    tabKnowledge: 'Knowledge Base',
    tabSettings: 'Settings',
    tabAccount: 'Account',
    personaSettings: 'Custom Personas',
    personaHelp: 'Create multiple AI personas. Click anywhere to expand prompt.',
    addPersona: '+ Add Persona',
    templateLibrary: 'Template Library',
    livePreview: 'Live Preview',
    previewHelp: 'Test your active persona in real-time.',
    previewPlaceholder: 'Type a test message...',
    sendBtn: 'Send',
    previewThinking: 'AI thinking...',
    previewError: 'Error: ',
    faq: 'Knowledge Base / FAQ',
    faqHelp: 'Add common Q&A. AI will naturally weave this info into replies.',
    faqSearchPlaceholder: 'Search Q&A...',
    allCategories: 'All Categories',
    catProduct: 'Product',
    catPrice: 'Pricing',
    catService: 'Service',
    catOther: 'Other',
    batchSelectAll: 'Select All',
    batchCountPrefix: '',
    batchCountSuffix: ' selected',
    batchDelete: 'Delete',
    batchMoveTo: 'Move to category...',
    smartCategorize: 'Smart Categorize',
    addFaq: '+ Add Q&A',
    importBtn: 'Import',
    exportBtn: 'Export',
    replySettings: 'Reply Preferences',
    tone: 'Reply Tone',
    toneAuto: 'Auto (Context-based)',
    tonePro: 'Professional',
    toneFriendly: 'Friendly & Warm',
    toneEmpathetic: 'Empathetic',
    toneDirect: 'Direct & Concise',
    replyLength: 'Reply Length',
    lenAuto: 'Auto',
    lenShort: 'Short (1-2 sentences)',
    lenMedium: 'Medium (2-4 sentences)',
    lenLong: 'Detailed',
    uiSettings: 'UI & Interaction',
    shortcut: 'Shortcut Key',
    shortcutHint: 'Alt+2 opens quick menu · Ctrl+Enter inserts reply · Ctrl+R regenerates',
    btnTheme: 'Floating Button Theme',
    themeGradient: 'Gradient Glow',
    themeMinimal: 'Minimalist',
    themeNeon: 'Cyber Neon',
    themeGlass: 'Glassmorphism',
    apiConfig: 'API Configuration',
    apiConfigDesc: 'Configure AI provider and API key.',
    apiProvider: 'API Provider',
    provider: 'Provider',
    apiKey: 'API Key',
    testConnection: 'Test Connection',
    apiConnected: 'Connected',
    apiDisconnected: 'Not connected',
    apiTesting: 'Testing...',
    apiTestSuccess: 'Connection successful!',
    apiTestFail: 'Connection failed: ',
    licenseStatus: 'License Status',
    licenseDesc: 'Currently using free version, limited to 20 replies per day. Upgrade to Pro for unlimited replies.',
    upgradeBtn: 'Upgrade to Pro',
    activatePlaceholder: 'Enter activation code (e.g. PRO-XXXX-XXXX)',
    activateLabel: 'Activate',
    activateVerifying: 'Verifying...',
    activateSuccessPrefix: 'Activated! Upgraded to ',
    activateErrorEmpty: 'Please enter activation code',
    activateErrorInvalid: 'Invalid code. Please check and try again',
    activateFail: 'Activation failed. Please check your network',
    dataBackup: 'Data Backup',
    dataBackupDesc: 'Export or import all settings (personas, FAQ, preferences, API config).',
    exportAllSettings: 'Export All Settings',
    importSettings: 'Import Settings',
    statReplies: 'Total Replies:',
    statSuccess: 'Success Rate:',
    statQuota: 'Today Quota:',
    saved: 'Saved',
    saving: 'Saving...',
    unsaved: 'Unsaved',
    noMatchingPersonas: 'No matching personas found',
    noMatchingFaq: 'No matching Q&A found',
    confirmDeletePersona: 'Are you sure you want to delete this persona?',
    confirmDeleteFaq: 'Delete this Q&A?',
    confirmBatchDelete: 'Are you sure you want to delete {n} selected Q&A items?',
    deletedCount: 'Deleted {n} Q&A items',
    categoryUpdated: 'Updated category for {n} Q&A items',
    smartCategorizeDone: 'Smart categorization complete! Updated {n} items',
    importSuccess: 'Imported {n} Q&A items',
    importNoValid: 'No valid Q&A items found',
    importInvalidFormat: 'Invalid file format',
    importParseFail: 'Failed to parse JSON',
    exportSuccess: 'Exported {n} Q&A items',
    exportNone: 'No Q&A items to export',
    templateAdded: 'Template added: {name}',
    personaNamePlaceholder: 'Persona Name',
    statusActive: 'Active',
    statusInactive: 'Inactive',
    toggleActive: 'Active',
    toggleSetAsActive: 'Set as Active',
    questionLabel: 'Question',
    answerLabel: 'Answer',
    upgradeModalTitle: 'Upgrade to ChatGenius Pro',
    upgradeOptCodeTitle: 'I have an activation code',
    upgradeOptBuyTitle: 'Purchase Online',
    close: 'Close',
    statProLifetime: 'Pro Lifetime',
    statProYear: 'Pro Year',
    statFree: 'Free',
    templateSales: 'Sales Manager',
    templateSalesDesc: 'Professional sales representative for product promotion',
    templateSupport: 'Customer Support',
    templateSupportDesc: 'Friendly support agent for customer inquiries',
    templateTech: 'Technical Support',
    templateTechDesc: 'Expert technical advisor for product issues',
    templateProduct: 'Product Consultant',
    templateProductDesc: 'Knowledgeable consultant for product recommendations',
    templateSuccess: 'Customer Success',
    templateSuccessDesc: 'Dedicated manager for customer onboarding',
    undoDelete: 'Undo',
    deletedFaq: 'Deleted 1 Q&A item',
    importSettingsSuccess: 'Settings imported successfully!',
    importSettingsFail: 'Failed to import settings',
    exportSettingsSuccess: 'Settings exported!',
    exportSettingsNone: 'No settings to export',
    personaPromptPlaceholder: 'System Prompt\n\nExample: You are a professional customer service representative...',
    freeTierQuota: 'Today remaining {n} replies',
    freeTierUpgrade: 'Upgrade Pro'
  },
  zh: {
    title: 'ChatGenius AI 设置',
    subtitle: '管理你的 AI 角色、知识库和偏好',
    tabPersonas: 'AI 角色',
    tabKnowledge: '知识库',
    tabSettings: '设置',
    tabAccount: '账户',
    personaSettings: '自定义角色',
    personaHelp: '创建多个 AI 角色，点击任意位置展开 prompt。',
    addPersona: '+ 添加角色',
    templateLibrary: '模板库',
    livePreview: '实时预览',
    previewHelp: '测试当前激活角色的回复效果。',
    previewPlaceholder: '输入测试消息...',
    sendBtn: '发送',
    previewThinking: 'AI 思考中...',
    previewError: '错误: ',
    faq: '知识库 / FAQ',
    faqHelp: '添加常见问答，AI 会自然融入这些信息。',
    faqSearchPlaceholder: '搜索问答...',
    allCategories: '全部分类',
    catProduct: '产品相关',
    catPrice: '价格咨询',
    catService: '售后服务',
    catOther: '其他',
    batchSelectAll: '全选',
    batchDelete: '删除',
    batchMoveTo: '移动到分类...',
    smartCategorize: '智能分类',
    addFaq: '+ 添加问答',
    importBtn: '导入',
    exportBtn: '导出',
    replySettings: '回复偏好',
    tone: '回复语气',
    toneAuto: '自动 (根据语境)',
    tonePro: '专业严谨',
    toneFriendly: '热情友好',
    toneEmpathetic: '共情理解',
    toneDirect: '直接干练',
    replyLength: '回复长度',
    lenAuto: '自动',
    lenShort: '简短 (1-2句话)',
    lenMedium: '适中 (2-4句话)',
    lenLong: '详细',
    uiSettings: '界面与交互',
    shortcut: '快捷键',
    shortcutHint: 'Alt+2 打开快捷菜单 · Ctrl+Enter 插入回复 · Ctrl+R 重新生成',
    btnTheme: '悬浮按钮主题',
    themeGradient: '渐变发光',
    themeMinimal: '极简主义',
    themeNeon: '赛博霓虹',
    themeGlass: '毛玻璃',
    apiConfig: 'API 配置',
    apiConfigDesc: '配置 AI 服务提供商和 API 密钥。',
    apiProvider: 'API 提供商',
    provider: '提供商',
    apiKey: 'API Key',
    testConnection: '测试连接',
    apiConnected: '已连接',
    apiDisconnected: '未连接',
    apiTesting: '测试中...',
    apiTestSuccess: '连接成功！',
    apiTestFail: '连接失败: ',
    licenseStatus: '许可证状态',
    licenseDesc: '当前使用免费版，每日限 20 次回复。升级到 Pro 版享受无限次回复和高级功能。',
    upgradeBtn: '升级至 Pro 版',
    activatePlaceholder: '输入激活码（例如：PRO-XXXX-XXXX）',
    activateLabel: '激活',
    activateVerifying: '验证中...',
    activateSuccessPrefix: '激活成功！已升级到 ',
    activateErrorEmpty: '请输入激活码',
    activateErrorInvalid: '激活码无效，请检查后重试',
    activateFail: '激活失败，请检查网络连接',
    dataBackup: '数据备份',
    dataBackupDesc: '导出或导入全部设置（包括角色、FAQ、偏好和 API 配置）。',
    exportAllSettings: '导出全部设置',
    importSettings: '导入设置',
    statReplies: '累计回复:',
    statSuccess: '成功率:',
    statQuota: '今日配额:',
    saved: '已保存',
    saving: '保存中...',
    unsaved: '未保存',
    noMatchingPersonas: '没有找到匹配的角色',
    noMatchingFaq: '没有找到匹配的问答',
    confirmDeletePersona: '确定要删除这个角色吗？',
    confirmDeleteFaq: '确定删除此问答？',
    confirmBatchDelete: '确定要删除选中的 {n} 条问答吗？',
    deletedCount: '已删除 {n} 条问答',
    categoryUpdated: '已更新 {n} 条问答的分类',
    smartCategorizeDone: '智能分类完成！更新了 {n} 条问答',
    importSuccess: '成功导入 {n} 条问答',
    importNoValid: '文件中没有有效的问答数据',
    importInvalidFormat: '文件格式不正确',
    importParseFail: '解析JSON失败',
    exportSuccess: '已导出 {n} 条问答',
    exportNone: '没有可导出的问答',
    templateAdded: '已添加模板：{name}',
    personaNamePlaceholder: '角色名称',
    statusActive: '当前使用',
    statusInactive: '未激活',
    toggleActive: '当前激活',
    toggleSetAsActive: '切换为当前角色',
    questionLabel: '问题',
    answerLabel: '答案',
    upgradeModalTitle: '升级 ChatGenius Pro',
    upgradeOptCodeTitle: '我有激活码',
    upgradeOptBuyTitle: '在线购买',
    close: '关闭',
    statProLifetime: 'Pro 永久版',
    statProYear: 'Pro 年付版',
    statFree: '免费版',
    templateSales: '销售经理',
    templateSalesDesc: '专业的产品推广销售代表',
    templateSupport: '客服代表',
    templateSupportDesc: '友好的客户咨询支持专员',
    templateTech: '技术支持',
    templateTechDesc: '专业的技术问题解答顾问',
    templateProduct: '产品顾问',
    templateProductDesc: '知识丰富的产品推荐专家',
    templateSuccess: '客户成功经理',
    templateSuccessDesc: '专注于客户引导和服务的经理',
    undoDelete: '撤销',
    deletedFaq: '已删除 1 条问答',
    importSettingsSuccess: '设置导入成功！',
    importSettingsFail: '导入设置失败',
    exportSettingsSuccess: '设置已导出！',
    exportSettingsNone: '没有可导出的设置',
    personaPromptPlaceholder: '系统提示词 (Prompt)\n\n例如：你是一个专业的客服代表，负责解答客户关于产品的疑问...',
    freeTierQuota: '今日剩余 {n} 次回复机会',
    freeTierUpgrade: '升级 Pro'
  }
};

// Persona Templates
const PERSONA_TEMPLATES = [
  { id: 'sales', icon: '💼', nameKey: 'templateSales', descKey: 'templateSalesDesc', prompt: '你是[公司名称]的销售经理。你的目标是了解客户需求，推荐合适的产品，并促成交易。\n\n回复时请：\n1. 礼貌热情，展现专业形象\n2. 主动询问客户的具体需求（如产品类型、数量、预算等）\n3. 根据需求推荐最适合的产品\n4. 在适当时机引导客户下单或索取联系方式\n\n语气：专业但友好，让客户感受到诚意。' },
  { id: 'support', icon: '🎧', nameKey: 'templateSupport', descKey: 'templateSupportDesc', prompt: '你是[公司名称]的客服代表。你的职责是解答客户疑问，处理投诉，提供满意的服务体验。\n\n回复时请：\n1. 保持耐心和同理心\n2. 清晰解答客户的问题\n3. 主动提供解决方案\n4. 必要时引导客户联系人工客服\n\n语气：温暖友好，让客户感到被重视。' },
  { id: 'tech', icon: '🔧', nameKey: 'templateTech', descKey: 'templateTechDesc', prompt: '你是[公司名称]的技术支持专家。你负责解决客户在使用产品过程中遇到的技术问题。\n\n回复时请：\n1. 准确理解客户描述的问题\n2. 提供清晰的解决步骤\n3. 必要时询问更多细节（如错误信息、设备型号等）\n4. 复杂问题建议提交工单\n\n语气：专业严谨，但通俗易懂。' },
  { id: 'product', icon: '', nameKey: 'templateProduct', descKey: 'templateProductDesc', prompt: '你是[公司名称]的产品顾问。你对所有产品特性了如指掌，能为客户提供专业的产品建议。\n\n回复时请：\n1. 了解客户的使用场景和需求\n2. 对比不同产品的优劣\n3. 推荐最匹配的产品方案\n4. 解释推荐理由\n\n语气：专业且具有说服力。' },
  { id: 'success', icon: '⭐', nameKey: 'templateSuccess', descKey: 'templateSuccessDesc', prompt: '你是[公司名称]的客户成功经理。你的目标是帮助客户成功使用产品，提升满意度和留存率。\n\n回复时请：\n1. 了解客户当前的使用情况\n2. 主动提供使用建议和最佳实践\n3. 关注客户可能遇到的困难\n4. 引导客户充分利用产品功能\n\n语气：亲切关怀，展现长期服务的诚意。' }
];

// ================================
// Main
// ================================
document.addEventListener('DOMContentLoaded', () => {
  // ---- State ----
  let currentLang = 'zh';
  let currentTheme = 'light';
  let faqData = [];
  let personas = [];
  let activePersonaId = null;
  let faqSearchQuery = '';
  let faqCategoryQuery = 'all';
  let selectedFaqIndices = new Set();
  let deletedFaqUndo = null; // { items: [], timer }

  // ---- Auto-save ----
  let saveTimer = null;
  const SAVE_DELAY = 500;

  function scheduleSave() {
    updateSaveStatus('saving');
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      doSave();
    }, SAVE_DELAY);
  }

  function doSave() {
    // Save all items including empty ones (new items being edited)
    const tone = document.getElementById('tone')?.value || 'auto';
    const replyLength = document.getElementById('replyLength')?.value || 'auto';
    const btnTheme = document.getElementById('btnTheme')?.value || 'gradient';
    const shortcut = document.getElementById('shortcut')?.value || '';
    const apiProvider = document.getElementById('apiProvider')?.value || 'openai';
    const apiKey = document.getElementById('apiKey')?.value || '';

    chrome.storage.sync.set({
      personas: personas,
      activePersonaId,
      tone,
      replyLength,
      faqData: faqData,
      btnTheme,
      shortcut,
      apiProvider,
      apiKey,
      theme: currentTheme,
      lang: currentLang
    }, () => {
      updateSaveStatus('saved');
    });
  }

  function updateSaveStatus(status) {
    const statReplies = document.getElementById('statReplies');
    // We'll show save status in the footer
    const footer = document.querySelector('.footer-status-bar');
    if (!footer) return;
    let statusEl = document.getElementById('saveStatusEl');
    if (!statusEl) {
      statusEl = document.createElement('div');
      statusEl.id = 'saveStatusEl';
      statusEl.className = 'footer-status-item';
      footer.appendChild(statusEl);
    }
    const L = I18N[currentLang];
    if (status === 'saved') {
      statusEl.innerHTML = '<span style="color:var(--success);font-weight:600;">✓ ' + (L.saved || 'Saved') + '</span>';
    } else if (status === 'saving') {
      statusEl.innerHTML = '<span style="color:var(--text-tertiary);">' + (L.saving || 'Saving...') + '</span>';
    }
  }

  // ---- Tab Navigation ----
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      tabContents.forEach(content => {
        content.classList.remove('active');
        if (content.id === 'tab-' + targetTab) {
          content.classList.add('active');
        }
      });
    });
  });

  // Switch to pending tab
  chrome.storage.local.get(['pendingOptionsTab'], (data) => {
    if (data.pendingOptionsTab) {
      chrome.storage.local.remove('pendingOptionsTab');
      const targetBtn = document.querySelector('.tab-btn[data-tab="' + data.pendingOptionsTab + '"]');
      if (targetBtn) targetBtn.click();
    }
  });

  // ---- Theme Toggle ----
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const themeIconLight = document.getElementById('themeIconLight');
  const themeIconDark = document.getElementById('themeIconDark');

  function updateThemeIcons() {
    if (currentTheme === 'dark') {
      themeIconLight.style.display = 'none';
      themeIconDark.style.display = 'block';
    } else {
      themeIconLight.style.display = 'block';
      themeIconDark.style.display = 'none';
    }
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      currentTheme = currentTheme === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', currentTheme);
      updateThemeIcons();
      scheduleSave();
    });
  }

  // ---- Toast ----
  function showToast(msg, isError) {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toastMsg');
    if (!toast || !toastMsg) return;
    toastMsg.textContent = msg;
    toast.className = (isError ? 'error ' : '') + 'show';
    setTimeout(() => { toast.className = toast.className.replace('show', '').trim(); }, 2500);
  }

  // ---- I18n ----
  function applyI18n() {
    document.documentElement.lang = currentLang === 'zh' ? 'zh-CN' : 'en';
    document.title = I18N[currentLang].title || 'ChatGenius AI';
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (I18N[currentLang][key]) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.placeholder = I18N[currentLang][key];
        } else {
          el.textContent = I18N[currentLang][key];
        }
      }
    });
  }

  // ---- Persona Rendering ----
  const personaList = document.getElementById('personaList');

  function renderPersonas() {
    if (!personaList) return;
    personaList.innerHTML = '';

    if (personas.length === 0) {
      const empty = document.createElement('div');
      empty.style.cssText = 'padding:24px;text-align:center;color:var(--text-tertiary);font-size:14px;';
      empty.textContent = I18N[currentLang].noMatchingPersonas || 'No personas yet. Click "Add Persona" to create one.';
      personaList.appendChild(empty);
      return;
    }

    personas.forEach((persona, index) => {
      const isActive = persona.id === activePersonaId;
      const card = document.createElement('div');
      card.className = 'persona-card' + (isActive ? ' active' : '');

      // Header
      const header = document.createElement('div');
      header.className = 'persona-card-header';

      const avatar = document.createElement('div');
      avatar.className = 'persona-avatar';
      avatar.textContent = '🤖';

      const info = document.createElement('div');
      info.className = 'persona-info';

      const nameInput = document.createElement('input');
      nameInput.type = 'text';
      nameInput.className = 'persona-name-input';
      nameInput.placeholder = I18N[currentLang].personaNamePlaceholder || 'Persona Name';
      nameInput.value = persona.name;
      nameInput.addEventListener('input', (e) => { personas[index].name = e.target.value; scheduleSave(); });
      nameInput.addEventListener('click', (e) => e.stopPropagation());

      const status = document.createElement('div');
      status.className = 'persona-status' + (isActive ? ' active' : '');
      status.innerHTML = '<span class="persona-status-dot"></span><span>' +
        (isActive ? (I18N[currentLang].statusActive || 'Active') : (I18N[currentLang].statusInactive || 'Inactive')) +
        '</span>';

      info.appendChild(nameInput);
      info.appendChild(status);

      const actions = document.createElement('div');
      actions.className = 'persona-actions';

      const delBtn = document.createElement('button');
      delBtn.className = 'persona-action-btn delete';
      delBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>';
      delBtn.title = 'Delete';
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(I18N[currentLang].confirmDeletePersona || 'Delete this persona?')) {
          personas.splice(index, 1);
          if (activePersonaId === persona.id) {
            activePersonaId = personas.length > 0 ? personas[0].id : null;
          }
          renderPersonas();
          scheduleSave();
        }
      });

      actions.appendChild(delBtn);
      header.appendChild(avatar);
      header.appendChild(info);
      header.appendChild(actions);

      // Click card to toggle prompt
      card.addEventListener('click', () => {
        const promptInput = card.querySelector('.persona-prompt-input');
        if (promptInput) {
          promptInput.classList.toggle('persona-prompt-collapsed');
        }
      });

      // Prompt textarea
      const promptInput = document.createElement('textarea');
      promptInput.className = 'persona-prompt-input' + (!isActive ? ' persona-prompt-collapsed' : '');
      promptInput.placeholder = I18N[currentLang].personaPromptPlaceholder || 'System Prompt...';
      promptInput.value = persona.prompt;
      promptInput.addEventListener('input', (e) => { personas[index].prompt = e.target.value; scheduleSave(); });
      promptInput.addEventListener('click', (e) => e.stopPropagation());

      // Toggle active button
      const toggleBtn = document.createElement('button');
      toggleBtn.className = 'persona-toggle-btn';
      toggleBtn.textContent = isActive
        ? (I18N[currentLang].toggleActive || 'Active')
        : (I18N[currentLang].toggleSetAsActive || 'Set as Active');
      if (!isActive) {
        toggleBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          activePersonaId = persona.id;
          renderPersonas();
          scheduleSave();
        });
      }

      card.appendChild(header);
      card.appendChild(promptInput);
      card.appendChild(toggleBtn);
      personaList.appendChild(card);
    });
  }

  // Add persona
  const addPersonaBtn = document.getElementById('addPersonaBtn');
  if (addPersonaBtn) {
    addPersonaBtn.addEventListener('click', () => {
      const newId = Math.random().toString(36).substr(2, 9);
      personas.push({ id: newId, name: '', prompt: '' });
      activePersonaId = newId;
      renderPersonas();
      scheduleSave();
      setTimeout(() => {
        const cards = personaList.querySelectorAll('.persona-card');
        cards.forEach(c => {
          const nameInput = c.querySelector('.persona-name-input');
          if (nameInput && !nameInput.value) nameInput.focus();
        });
      }, 50);
    });
  }

  // Template Library
  const templateLibraryBtn = document.getElementById('templateLibraryBtn');
  const templateModal = document.getElementById('templateModal');
  const templateGrid = document.getElementById('templateGrid');
  const closeTemplateBtn = document.getElementById('closeTemplateBtn');

  function renderTemplateLibrary() {
    if (!templateGrid) return;
    templateGrid.innerHTML = '';
    PERSONA_TEMPLATES.forEach(template => {
      const card = document.createElement('div');
      card.className = 'persona-card';
      card.style.cursor = 'pointer';

      const header = document.createElement('div');
      header.className = 'persona-card-header';

      const avatar = document.createElement('div');
      avatar.className = 'persona-avatar';
      avatar.textContent = template.icon;

      const info = document.createElement('div');
      info.className = 'persona-info';

      const name = document.createElement('div');
      name.style.cssText = 'font-size:14px;font-weight:600;color:var(--text-primary);margin-bottom:4px;';
      name.textContent = I18N[currentLang][template.nameKey] || template.nameKey;

      const desc = document.createElement('div');
      desc.style.cssText = 'font-size:12px;color:var(--text-secondary);';
      desc.textContent = I18N[currentLang][template.descKey] || template.descKey;

      info.appendChild(name);
      info.appendChild(desc);
      header.appendChild(avatar);
      header.appendChild(info);
      card.appendChild(header);

      card.addEventListener('click', () => {
        const newId = Math.random().toString(36).substr(2, 9);
        personas.push({
          id: newId,
          name: I18N[currentLang][template.nameKey] || template.nameKey,
          prompt: template.prompt
        });
        if (!activePersonaId) activePersonaId = newId;
        renderPersonas();
        scheduleSave();
        if (templateModal) templateModal.classList.remove('show');
        showToast((I18N[currentLang].templateAdded || 'Template added: {name}').replace('{name}', I18N[currentLang][template.nameKey] || template.nameKey));
      });

      templateGrid.appendChild(card);
    });
  }

  if (templateLibraryBtn) {
    templateLibraryBtn.addEventListener('click', () => {
      renderTemplateLibrary();
      if (templateModal) templateModal.classList.add('show');
    });
  }
  if (closeTemplateBtn) {
    closeTemplateBtn.addEventListener('click', () => { if (templateModal) templateModal.classList.remove('show'); });
  }
  if (templateModal) {
    templateModal.addEventListener('click', (e) => { if (e.target === templateModal) templateModal.classList.remove('show'); });
  }

  // ---- Live Preview ----
  const previewChat = document.getElementById('previewChat');
  const previewInput = document.getElementById('previewInput');
  const previewSendBtn = document.getElementById('previewSendBtn');

  function addPreviewMessage(text, type) {
    if (!previewChat) return;
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble ' + type;
    bubble.textContent = text;
    previewChat.appendChild(bubble);
    previewChat.scrollTop = previewChat.scrollHeight;
  }

  if (previewSendBtn) {
    previewSendBtn.addEventListener('click', async () => {
      const text = previewInput?.value.trim();
      if (!text) return;
      addPreviewMessage(text, 'user');
      if (previewInput) previewInput.value = '';

      const thinkingBubble = document.createElement('div');
      thinkingBubble.className = 'chat-bubble ai';
      thinkingBubble.innerHTML = '<span style="opacity:0.5;">' + (I18N[currentLang].previewThinking || 'AI thinking...') + '</span>';
      previewChat.appendChild(thinkingBubble);
      previewChat.scrollTop = previewChat.scrollHeight;

      try {
        const historyMessages = [];
        previewChat.querySelectorAll('.chat-bubble').forEach((bubble) => {
          if (bubble !== thinkingBubble) {
            historyMessages.push({
              role: bubble.classList.contains('user') ? 'user' : 'assistant',
              content: bubble.textContent
            });
          }
        });

        const response = await Promise.race([
          chrome.runtime.sendMessage({ action: 'previewChat', messages: historyMessages }),
          new Promise((_, reject) => setTimeout(() => reject(new Error('请求超时，请重试')), 35000))
        ]);

        if (response?.success && response.reply) {
          thinkingBubble.textContent = response.reply;
          thinkingBubble.style.opacity = '1';
        } else {
          thinkingBubble.innerHTML = '<span style="color:var(--error);">' + (I18N[currentLang].previewError || 'Error: ') + (response?.error || '') + '</span>';
        }
      } catch (error) {
        thinkingBubble.innerHTML = '<span style="color:var(--error);">' + (I18N[currentLang].previewError || 'Error: ') + error.message + '</span>';
      }
    });
  }

  // Enter key to send preview
  if (previewInput) {
    previewInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && previewSendBtn) previewSendBtn.click();
    });
  }

  // ---- FAQ Rendering ----
  const faqList = document.getElementById('faqList');
  const faqSearchInput = document.getElementById('faqSearch');
  const faqCategoryFilter = document.getElementById('faqCategoryFilter');
  const faqBatchToolbar = document.getElementById('faqBatchToolbar');
  const faqSelectAll = document.getElementById('faqSelectAll');
  const batchCount = document.getElementById('batchCount');
  const batchDeleteBtn = document.getElementById('batchDeleteBtn');
  const batchCategorySelect = document.getElementById('batchCategorySelect');
  const smartCategorizeBtn = document.getElementById('smartCategorizeBtn');

  function getFaqCategories() {
    return {
      product: { label: I18N[currentLang].catProduct || 'Product', color: '#667eea' },
      price: { label: I18N[currentLang].catPrice || 'Pricing', color: '#34c759' },
      service: { label: I18N[currentLang].catService || 'Service', color: '#ff9500' },
      other: { label: I18N[currentLang].catOther || 'Other', color: '#86868b' }
    };
  }

  function updateBatchToolbar() {
    if (!faqBatchToolbar || !batchCount) return;
    const count = selectedFaqIndices.size;
    batchCount.textContent = (I18N[currentLang].batchCountPrefix || '') + count + (I18N[currentLang].batchCountSuffix || ' selected');
    faqBatchToolbar.style.display = count > 0 ? 'flex' : 'none';
    const visibleItems = faqList?.querySelectorAll('.faq-item') || [];
    const allVisibleSelected = visibleItems.length > 0 && Array.from(visibleItems).every(item => {
      const cb = item.querySelector('.faq-item-checkbox');
      return cb && cb.checked;
    });
    if (faqSelectAll) faqSelectAll.checked = allVisibleSelected;
  }

  function renderFaq() {
    if (!faqList) return;
    faqList.innerHTML = '';

    const filteredFaq = [];
    faqData.forEach((item, index) => {
      if (faqCategoryQuery !== 'all' && item.category !== faqCategoryQuery) return;
      if (faqSearchQuery) {
        const query = faqSearchQuery.toLowerCase();
        if (!item.q.toLowerCase().includes(query) && !item.a.toLowerCase().includes(query)) return;
      }
      filteredFaq.push({ item, originalIndex: index });
    });

    if (filteredFaq.length === 0 && faqData.length > 0) {
      const noResults = document.createElement('div');
      noResults.style.cssText = 'padding:24px;text-align:center;color:var(--text-tertiary);font-size:14px;';
      noResults.textContent = I18N[currentLang].noMatchingFaq || 'No matching Q&A found';
      faqList.appendChild(noResults);
      updateBatchToolbar();
      return;
    }

    filteredFaq.forEach(({ item, originalIndex: index }) => {
      const div = document.createElement('div');
      div.className = 'faq-item' + (selectedFaqIndices.has(index) ? ' selected' : '');

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'faq-item-checkbox';
      checkbox.id = 'faq-' + index;
      checkbox.checked = selectedFaqIndices.has(index);
      checkbox.addEventListener('change', (e) => {
        if (e.target.checked) selectedFaqIndices.add(index);
        else selectedFaqIndices.delete(index);
        updateBatchToolbar();
      });
      div.appendChild(checkbox);

      const headerRow = document.createElement('div');
      headerRow.className = 'faq-item-header';

      const cats = getFaqCategories();
      const catSelect = document.createElement('select');
      catSelect.className = 'faq-item-input';
      catSelect.style.cssText = 'width:auto;min-width:100px;flex:0;';
      Object.entries(cats).forEach(([key, info]) => {
        const opt = document.createElement('option');
        opt.value = key;
        opt.textContent = info.label;
        if (key === (item.category || 'other')) opt.selected = true;
        catSelect.appendChild(opt);
      });
      catSelect.addEventListener('change', (e) => { faqData[index].category = e.target.value; scheduleSave(); });

      const delBtn = document.createElement('button');
      delBtn.className = 'btn-sm btn-destructive';
      delBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>';
      delBtn.addEventListener('click', () => {
        // Delete with undo
        const deletedItem = faqData.splice(index, 1)[0];
        deletedFaqUndo = { items: [{ item: deletedItem, index }], timer: null };
        renderFaq();
        scheduleSave();
        showToast(I18N[currentLang].deletedFaq || 'Deleted 1 Q&A item');

        // Show undo toast
        const toast = document.getElementById('toast');
        const toastMsg = document.getElementById('toastMsg');
        if (toast && toastMsg) {
          toastMsg.textContent = I18N[currentLang].deletedFaq || 'Deleted';
          // Add undo button
          const undoBtn = document.createElement('button');
          undoBtn.textContent = I18N[currentLang].undoDelete || 'Undo';
          undoBtn.style.cssText = 'margin-left:8px;color:var(--accent);background:none;border:none;cursor:pointer;font-weight:600;font-size:13px;';
          undoBtn.addEventListener('click', () => {
            faqData.splice(deletedFaqUndo.items[0].index, 0, deletedFaqUndo.items[0].item);
            deletedFaqUndo = null;
            renderFaq();
            scheduleSave();
            toast.className = toast.className.replace('show', '').trim();
          });
          toast.appendChild(undoBtn);
          toast.className = 'show';
          clearTimeout(deletedFaqUndo.timer);
          deletedFaqUndo.timer = setTimeout(() => {
            toast.className = toast.className.replace('show', '').trim();
            deletedFaqUndo = null;
          }, 3000);
        }
      });

      headerRow.appendChild(catSelect);
      headerRow.appendChild(delBtn);
      div.appendChild(headerRow);

      const qInput = document.createElement('input');
      qInput.className = 'faq-item-input question';
      qInput.placeholder = I18N[currentLang].questionLabel || 'Question';
      qInput.value = item.q;
      qInput.style.marginBottom = '8px';
      qInput.addEventListener('input', (e) => { faqData[index].q = e.target.value; scheduleSave(); });

      const aInput = document.createElement('textarea');
      aInput.className = 'faq-item-input';
      aInput.placeholder = I18N[currentLang].answerLabel || 'Answer';
      aInput.value = item.a;
      aInput.rows = 3;
      aInput.addEventListener('input', (e) => { faqData[index].a = e.target.value; scheduleSave(); });

      div.appendChild(qInput);
      div.appendChild(aInput);
      faqList.appendChild(div);
    });

    updateBatchToolbar();
  }

  if (faqSearchInput) {
    faqSearchInput.addEventListener('input', (e) => { faqSearchQuery = e.target.value.trim(); renderFaq(); });
  }
  if (faqCategoryFilter) {
    faqCategoryFilter.addEventListener('change', (e) => { faqCategoryQuery = e.target.value; renderFaq(); });
  }

  // Select all
  if (faqSelectAll) {
    faqSelectAll.addEventListener('change', (e) => {
      faqList.querySelectorAll('.faq-item-checkbox').forEach(cb => {
        cb.checked = e.target.checked;
        const idx = parseInt(cb.id.replace('faq-', ''));
        if (e.target.checked) selectedFaqIndices.add(idx);
        else selectedFaqIndices.delete(idx);
      });
      updateBatchToolbar();
    });
  }

  // Batch delete
  if (batchDeleteBtn) {
    batchDeleteBtn.addEventListener('click', () => {
      if (selectedFaqIndices.size === 0) return;
      const count = selectedFaqIndices.size;
      if (confirm((I18N[currentLang].confirmBatchDelete || 'Delete {n} items?').replace('{n}', count))) {
        const sortedIndices = Array.from(selectedFaqIndices).sort((a, b) => b - a);
        sortedIndices.forEach(idx => faqData.splice(idx, 1));
        selectedFaqIndices.clear();
        renderFaq();
        scheduleSave();
        showToast((I18N[currentLang].deletedCount || 'Deleted {n}').replace('{n}', count));
      }
    });
  }

  // Batch category
  if (batchCategorySelect) {
    batchCategorySelect.addEventListener('change', (e) => {
      const category = e.target.value;
      if (!category || selectedFaqIndices.size === 0) return;
      selectedFaqIndices.forEach(idx => { if (faqData[idx]) faqData[idx].category = category; });
      e.target.value = '';
      renderFaq();
      scheduleSave();
      showToast((I18N[currentLang].categoryUpdated || 'Updated {n}').replace('{n}', selectedFaqIndices.size));
    });
  }

  // Smart categorize
  if (smartCategorizeBtn) {
    smartCategorizeBtn.addEventListener('click', () => {
      let changedCount = 0;
      faqData.forEach((item) => {
        const text = (item.q + ' ' + item.a).toLowerCase();
        let predictedCategory = 'other';
        if (/price|cost|payment|pay|cheap|expensive|discount|refund|美元|价格|费用|付款|支付|便宜|贵|折扣|退款|钱/i.test(text)) {
          predictedCategory = 'price';
        } else if (/product|item|feature|specification|size|color|material|quality|warranty|产品|商品|物品|功能|规格|尺寸|颜色|材质|质量|保修|型号/i.test(text)) {
          predictedCategory = 'product';
        } else if (/service|support|help|return|exchange|shipping|delivery|track|warranty|repair|服务|支持|帮助|退货|换货|发货|物流|跟踪|维修|售后/i.test(text)) {
          predictedCategory = 'service';
        }
        if (item.category !== predictedCategory) { item.category = predictedCategory; changedCount++; }
      });
      renderFaq();
      scheduleSave();
      showToast((I18N[currentLang].smartCategorizeDone || 'Updated {n}').replace('{n}', changedCount));
    });
  }

  // Add FAQ
  const addFaqBtn = document.getElementById('addFaqBtn');
  if (addFaqBtn) {
    addFaqBtn.addEventListener('click', () => { faqData.push({ q: '', a: '', category: 'other' }); renderFaq(); scheduleSave(); });
  }

  // FAQ Import/Export
  const importFaqBtn = document.getElementById('importFaqBtn');
  const exportFaqBtn = document.getElementById('exportFaqBtn');
  const faqFileInput = document.getElementById('faqFileInput');

  if (importFaqBtn && faqFileInput) {
    importFaqBtn.addEventListener('click', () => faqFileInput.click());
    faqFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const imported = JSON.parse(event.target.result);
          if (Array.isArray(imported)) {
            const validItems = imported.filter(item => item.q && item.a).map(item => ({ ...item, category: item.category || 'other' }));
            if (validItems.length > 0) {
              faqData = [...faqData, ...validItems];
              renderFaq();
              scheduleSave();
              showToast((I18N[currentLang].importSuccess || 'Imported {n}').replace('{n}', validItems.length));
            } else {
              showToast(I18N[currentLang].importNoValid || 'No valid Q&A items found', true);
            }
          } else {
            showToast(I18N[currentLang].importInvalidFormat || 'Invalid file format', true);
          }
        } catch (err) {
          showToast(I18N[currentLang].importParseFail || 'Failed to parse JSON', true);
        }
      };
      reader.readAsText(file);
      faqFileInput.value = '';
    });
  }

  if (exportFaqBtn) {
    exportFaqBtn.addEventListener('click', () => {
      const validFaq = faqData.filter(f => f.q.trim() && f.a.trim());
      if (validFaq.length === 0) { showToast(I18N[currentLang].exportNone || 'No Q&A items to export', true); return; }
      const dataStr = JSON.stringify(validFaq, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'faq-export-' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast((I18N[currentLang].exportSuccess || 'Exported {n}').replace('{n}', validFaq.length));
    });
  }

  // ---- Shortcut ----
  const shortcutInput = document.getElementById('shortcut');
  if (shortcutInput) {
    shortcutInput.addEventListener('keydown', (e) => {
      e.preventDefault();
      if (e.key === 'Backspace' || e.key === 'Delete') { shortcutInput.value = ''; scheduleSave(); return; }
      const keys = [];
      if (e.ctrlKey) keys.push('Ctrl');
      if (e.altKey) keys.push('Alt');
      if (e.shiftKey) keys.push('Shift');
      if (e.metaKey) keys.push('Cmd');
      if (e.key !== 'Control' && e.key !== 'Alt' && e.key !== 'Shift' && e.key !== 'Meta') {
        keys.push(e.key.toUpperCase());
      }
      if (keys.length > 0) { shortcutInput.value = keys.join(' + '); scheduleSave(); }
    });
  }

  // ---- API Configuration ----
  const apiProvider = document.getElementById('apiProvider');
  const apiKeyInput = document.getElementById('apiKey');
  const testApiBtn = document.getElementById('testApiBtn');
  const apiStatusIndicator = document.getElementById('apiStatusIndicator');
  const apiStatusText = document.getElementById('apiStatusText');

  if (apiProvider) {
    apiProvider.addEventListener('change', () => scheduleSave());
  }
  if (apiKeyInput) {
    apiKeyInput.addEventListener('input', () => scheduleSave());
  }

  if (testApiBtn) {
    testApiBtn.addEventListener('click', async () => {
      const provider = apiProvider?.value || 'openai';
      const key = apiKeyInput?.value.trim();
      if (!key) {
        showToast('Please enter API Key', true);
        return;
      }

      testApiBtn.disabled = true;
      testApiBtn.textContent = I18N[currentLang].apiTesting || 'Testing...';
      if (apiStatusIndicator) { apiStatusIndicator.className = 'api-status-indicator disconnected'; }
      if (apiStatusText) { apiStatusText.textContent = I18N[currentLang].apiTesting || 'Testing...'; }

      try {
        let testUrl, headers, body;
        if (provider === 'anthropic') {
          testUrl = 'https://api.anthropic.com/v1/messages';
          headers = { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' };
          body = JSON.stringify({ model: 'claude-3-haiku-20240307', max_tokens: 10, messages: [{ role: 'user', content: 'Hi' }] });
        } else if (provider === 'google') {
          testUrl = 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=' + key;
          headers = { 'Content-Type': 'application/json' };
          body = JSON.stringify({ contents: [{ parts: [{ text: 'Hi' }] }] });
        } else {
          testUrl = 'https://api.openai.com/v1/chat/completions';
          headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key };
          body = JSON.stringify({ model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: 'Hi' }], max_tokens: 10 });
        }

        const response = await fetch(testUrl, { method: 'POST', headers, body });
        if (response.ok) {
          if (apiStatusIndicator) { apiStatusIndicator.className = 'api-status-indicator connected'; }
          if (apiStatusText) { apiStatusText.textContent = I18N[currentLang].apiConnected || 'Connected'; }
          showToast(I18N[currentLang].apiTestSuccess || 'Connection successful!');
          // Save connection status
          chrome.storage.sync.set({ connectionValid: true });
        } else {
          const errData = await response.json().catch(() => ({}));
          const errMsg = errData.error?.message || errData.message || 'HTTP ' + response.status;
          if (apiStatusIndicator) { apiStatusIndicator.className = 'api-status-indicator disconnected'; }
          if (apiStatusText) { apiStatusText.textContent = I18N[currentLang].apiDisconnected || 'Not connected'; }
          showToast((I18N[currentLang].apiTestFail || 'Connection failed: ') + errMsg, true);
          chrome.storage.sync.set({ connectionValid: false });
        }
      } catch (error) {
        if (apiStatusIndicator) { apiStatusIndicator.className = 'api-status-indicator disconnected'; }
        if (apiStatusText) { apiStatusText.textContent = I18N[currentLang].apiDisconnected || 'Not connected'; }
        showToast((I18N[currentLang].apiTestFail || 'Connection failed: ') + error.message, true);
        chrome.storage.sync.set({ connectionValid: false });
      } finally {
        testApiBtn.disabled = false;
        testApiBtn.textContent = I18N[currentLang].testConnection || 'Test Connection';
      }
    });
  }

  // ---- Account: License & Activation ----
  const licenseBadge = document.getElementById('licenseBadge');
  const licenseTypeEl = document.getElementById('licenseType');
  const upgradeBtn = document.getElementById('upgradeBtn');
  const activationCodeInput = document.getElementById('activationCodeInput');
  const activateBtn = document.getElementById('activateBtn');
  const activationError = document.getElementById('activationError');
  const activationSuccess = document.getElementById('activationSuccess');
  const licenseTypeDisplay = document.getElementById('licenseTypeDisplay');

  function updateLicenseDisplay(licenseType) {
    if (!licenseBadge || !licenseTypeEl) return;
    const typeNames = {
      'lifetime': I18N[currentLang].statProLifetime || 'Pro Lifetime',
      'year': I18N[currentLang].statProYear || 'Pro Year',
      'free': I18N[currentLang].statFree || 'Free'
    };
    licenseTypeEl.textContent = typeNames[licenseType] || licenseType;
    licenseBadge.className = 'license-badge ' + (licenseType === 'free' ? 'free' : 'pro');
  }

  if (activateBtn && activationCodeInput) {
    activateBtn.addEventListener('click', async () => {
      const code = activationCodeInput.value.trim();
      if (!code) { activationError.textContent = I18N[currentLang].activateErrorEmpty || 'Please enter activation code'; return; }

      activateBtn.disabled = true;
      activateBtn.innerHTML = '<svg class="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" stroke-dasharray="60" stroke-dashoffset="40"></circle></svg><span>' + (I18N[currentLang].activateVerifying || 'Verifying...') + '</span>';
      activationError.textContent = '';

      try {
        const response = await fetch(API_BASE_URL + '/api/license/activate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: code.toUpperCase() })
        });
        const result = await response.json();

        if (result.valid && result.type) {
          await chrome.storage.sync.set({
            licenseCode: code.toUpperCase(),
            licenseType: result.type,
            activatedAt: result.activatedAt || new Date().toISOString()
          });
          activationSuccess.style.display = 'flex';
          licenseTypeDisplay.textContent = I18N[currentLang]['statPro' + (result.type === 'lifetime' ? 'Lifetime' : 'Year')] || result.type;
          activationCodeInput.value = '';
          updateLicenseDisplay(result.type);
          updateStats();
          updateFreeTierNotification();
          showToast((I18N[currentLang].activateSuccessPrefix || 'Activated! ') + result.type);
        } else {
          activationError.textContent = result.error || (I18N[currentLang].activateErrorInvalid || 'Invalid code');
        }
      } catch (error) {
        activationError.textContent = I18N[currentLang].activateFail || 'Activation failed';
      } finally {
        activateBtn.disabled = false;
        activateBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg><span>' + (I18N[currentLang].activateLabel || 'Activate') + '</span>';
      }
    });

    activationCodeInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') activateBtn.click(); });
  }

  // Upgrade button
  const upgradeModal = document.getElementById('upgradeModal');
  const closeUpgradeModal = document.getElementById('closeUpgradeModal');

  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: UPGRADE_URL });
    });
  }

  if (closeUpgradeModal) {
    closeUpgradeModal.addEventListener('click', () => { if (upgradeModal) upgradeModal.classList.remove('show'); });
  }
  if (upgradeModal) {
    upgradeModal.addEventListener('click', (e) => { if (e.target === upgradeModal) upgradeModal.classList.remove('show'); });
  }

  // Free tier notification
  const freeTierNotification = document.getElementById('freeTierNotification');
  const quotaRemaining = document.getElementById('quotaRemaining');
  const freeTierUpgradeBtn = document.getElementById('freeTierUpgradeBtn');

  function updateFreeTierNotification() {
    chrome.storage.sync.get(['licenseType'], (syncData) => {
      const licenseType = syncData.licenseType || 'free';
      if (licenseType !== 'free') {
        if (freeTierNotification) freeTierNotification.classList.remove('show');
        return;
      }
      chrome.storage.local.get(['dailyReplyCount', 'lastResetDate'], (usageData) => {
        const today = new Date().toISOString().split('T')[0];
        const effectiveCount = usageData.lastResetDate === today ? (usageData.dailyReplyCount || 0) : 0;
        const remaining = Math.max(0, DAILY_LIMIT - effectiveCount);
        if (remaining <= 5) {
          if (freeTierNotification) {
            freeTierNotification.classList.add('show');
            if (quotaRemaining) quotaRemaining.textContent = remaining;
          }
        } else {
          if (freeTierNotification) freeTierNotification.classList.remove('show');
        }
      });
    });
  }

  if (freeTierUpgradeBtn) {
    freeTierUpgradeBtn.addEventListener('click', () => { chrome.tabs.create({ url: UPGRADE_URL }); });
  }

  // ---- Data Backup ----
  const exportAllSettingsBtn = document.getElementById('exportAllSettingsBtn');
  const importAllSettingsBtn = document.getElementById('importAllSettingsBtn');
  const allSettingsFileInput = document.getElementById('allSettingsFileInput');

  if (exportAllSettingsBtn) {
    exportAllSettingsBtn.addEventListener('click', () => {
      chrome.storage.sync.get(null, (data) => {
        const settings = {
          personas: data.personas || [],
          activePersonaId: data.activePersonaId,
          tone: data.tone,
          replyLength: data.replyLength,
          faqData: data.faqData || [],
          btnTheme: data.btnTheme,
          shortcut: data.shortcut,
          apiProvider: data.apiProvider,
          licenseType: data.licenseType,
          licenseCode: data.licenseCode,
          activatedAt: data.activatedAt,
          exportDate: new Date().toISOString()
        };
        const dataStr = JSON.stringify(settings, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'chatgenius-settings-' + new Date().toISOString().slice(0, 10) + '.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast(I18N[currentLang].exportSettingsSuccess || 'Settings exported!');
      });
    });
  }

  if (importAllSettingsBtn && allSettingsFileInput) {
    importAllSettingsBtn.addEventListener('click', () => allSettingsFileInput.click());
    allSettingsFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const imported = JSON.parse(event.target.result);
          const settingsToSave = {};
          const keys = ['personas', 'activePersonaId', 'tone', 'replyLength', 'faqData', 'btnTheme', 'shortcut', 'apiProvider', 'licenseType', 'licenseCode', 'activatedAt'];
          keys.forEach(key => { if (imported[key] !== undefined) settingsToSave[key] = imported[key]; });

          chrome.storage.sync.set(settingsToSave, () => {
            // Reload state
            if (imported.personas) { personas = imported.personas; activePersonaId = imported.activePersonaId || (personas.length > 0 ? personas[0].id : null); }
            if (imported.faqData) faqData = imported.faqData;
            renderPersonas();
            renderFaq();
            updateLicenseDisplay(imported.licenseType || 'free');
            showToast(I18N[currentLang].importSettingsSuccess || 'Settings imported successfully!');
          });
        } catch (err) {
          showToast(I18N[currentLang].importSettingsFail || 'Failed to import settings', true);
        }
      };
      reader.readAsText(file);
      allSettingsFileInput.value = '';
    });
  }

  // ---- Stats Footer ----
  const statRepliesEl = document.getElementById('statReplies');
  const statSuccessEl = document.getElementById('statSuccess');
  const statQuotaEl = document.getElementById('statQuota');

  function updateStats() {
    chrome.storage.local.get({ totalReplies: 0, successCount: 0, failedCount: 0 }, (data) => {
      const replies = data.totalReplies || 0;
      const successCount = data.successCount || 0;
      const failedCount = data.failedCount || 0;
      if (statRepliesEl) statRepliesEl.textContent = replies.toLocaleString();
      if (statSuccessEl) {
        const total = successCount + failedCount;
        statSuccessEl.textContent = total > 0 ? Math.round((successCount / total) * 100) + '%' : '-';
      }
    });

    chrome.storage.sync.get(['licenseType'], (licenseData) => {
      const licenseType = licenseData.licenseType || 'free';
      if (licenseType === 'free') {
        chrome.storage.local.get(['dailyReplyCount', 'lastResetDate'], (usageData) => {
          const today = new Date().toISOString().split('T')[0];
          const effectiveCount = usageData.lastResetDate === today ? (usageData.dailyReplyCount || 0) : 0;
          if (statQuotaEl) statQuotaEl.textContent = effectiveCount + '/' + DAILY_LIMIT;
        });
      } else {
        if (statQuotaEl) statQuotaEl.textContent = I18N[currentLang]['statPro' + (licenseType === 'lifetime' ? 'Lifetime' : 'Year')] || licenseType;
      }
    });
  }

  // ---- Load Settings ----
  chrome.storage.sync.get({
    personas: [{ id: 'default', name: '默认角色 (Default)', prompt: '你是一个专业的AI助手。请根据用户的消息上下文进行专业、礼貌的回复。' }],
    activePersonaId: 'default',
    shortcut: 'Alt + 1',
    tone: 'auto',
    replyLength: 'auto',
    faqData: [],
    btnTheme: 'gradient',
    theme: 'light',
    lang: 'zh',
    apiProvider: 'openai',
    apiKey: '',
    licenseType: 'free',
    licenseCode: null,
    activatedAt: null,
    onboardingCompleted: false
  }, (data) => {
    currentTheme = data.theme || 'light';
    currentLang = data.lang || 'zh';
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateThemeIcons();
    applyI18n();

    personas = data.personas || [];
    activePersonaId = data.activePersonaId;
    if (personas.length > 0 && !activePersonaId) activePersonaId = personas[0].id;
    faqData = data.faqData || [];

    // Set form values
    const toneSelect = document.getElementById('tone');
    const replyLengthSelect = document.getElementById('replyLength');
    const btnThemeSelect = document.getElementById('btnTheme');
    if (toneSelect) toneSelect.value = data.tone || 'auto';
    if (replyLengthSelect) replyLengthSelect.value = data.replyLength || 'auto';
    if (btnThemeSelect) btnThemeSelect.value = data.btnTheme || 'gradient';
    if (shortcutInput) shortcutInput.value = data.shortcut || '';
    if (apiProvider) apiProvider.value = data.apiProvider || 'openai';
    if (apiKeyInput) apiKeyInput.value = data.apiKey || '';

    // Add change listeners for auto-save
    [toneSelect, replyLengthSelect, btnThemeSelect].forEach(el => {
      if (el) el.addEventListener('change', () => scheduleSave());
    });

    renderPersonas();
    renderFaq();
    updateLicenseDisplay(data.licenseType || 'free');

    // Check existing license
    if (data.licenseCode && data.licenseType && data.licenseType !== 'free') {
      if (activationSuccess) activationSuccess.style.display = 'flex';
      if (licenseTypeDisplay) {
        const typeNames = { 'lifetime': I18N[currentLang].statProLifetime, 'year': I18N[currentLang].statProYear };
        licenseTypeDisplay.textContent = typeNames[data.licenseType] || data.licenseType;
      }
    }

    updateStats();
    updateFreeTierNotification();
  });

  // Refresh stats periodically
  setInterval(updateStats, 30000);
  setInterval(updateFreeTierNotification, 60000);
});
