
function injectFonts() {
  if (!document.getElementById('wa-ai-fonts')) {
    const link = document.createElement('link');
    link.id = 'wa-ai-fonts';
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap';
    document.head.appendChild(link);
    
    const style = document.createElement('style');
    style.innerHTML = '@keyframes wa-ai-pulse {' +
                      '  0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(99, 102, 241, 0.4); }' +
                      '  70% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(99, 102, 241, 0); }' +
                      '  100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(99, 102, 241, 0); }' +
                      '}' +
                      '.wa-ai-pulse {' +
                      '  animation: wa-ai-pulse 2s infinite;' +
                      '}' +
                      '@keyframes holoGradient {' +
                      '  0% { background-position: 0% 50%; }' +
                      '  50% { background-position: 100% 50%; }' +
                      '  100% { background-position: 0% 50%; }' +
                      '}';
    document.head.appendChild(style);
  }
}

// Create floating status toast
function createStatusToast() {
  let toast = document.getElementById('wa-ai-status-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'wa-ai-status-toast';
    toast.style.cssText = `
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 10000;
      background: rgba(20, 20, 22, 0.85);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      color: #ffffff;
      padding: 12px 24px;
      border-radius: 100px;
      font-family: 'Inter', -apple-system, sans-serif;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.24);
      border: 1px solid rgba(255, 255, 255, 0.1);
      display: none;
      align-items: center;
      gap: 10px;
      transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
      opacity: 0;
      transform: translateX(-50%) translateY(-20px);
    `;
    document.body.appendChild(toast);
  }
  return toast;
}

function showToast(message, type = 'info', duration = 3000) {
  const toast = createStatusToast();
  let icon = '🤖';
  if (type === 'loading') icon = '<svg class="wa-ai-spin" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>';
  if (type === 'success') icon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
  if (type === 'error') icon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';

  toast.innerHTML = `<style>.wa-ai-spin { animation: wa-ai-spin 1s linear infinite; } @keyframes wa-ai-spin { 100% { transform: rotate(360deg); } }</style><span style="display:flex;align-items:center;">${icon}</span><span>${message}</span>`;
  toast.style.display = 'flex';
  
  // Trigger reflow
  void toast.offsetWidth;
  
  toast.style.opacity = '1';
  toast.style.transform = 'translateX(-50%) translateY(0)';

  if (duration > 0) {
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(-20px)';
      setTimeout(() => { toast.style.display = 'none'; }, 400);
    }, duration);
  }
}

// Platform detection
const PLATFORMS = {
  WHATSAPP: 'whatsapp',
  MESSENGER: 'messenger'
};

function detectPlatform() {
  const host = window.location.hostname;
  if (host.includes('whatsapp.com')) return PLATFORMS.WHATSAPP;
  if (host.includes('messenger.com') || host.includes('facebook.com')) return PLATFORMS.MESSENGER;
  return null;
}

// Make button draggable
function makeDraggable(el) {
  let isDragging = false;
  let startX, startY, initialLeft, initialTop;
  let animationFrameId = null;
  let currentX, currentY;

  el.addEventListener('pointerdown', dragStart);

  function dragStart(e) {
    if (e.button !== 0) return; // Only left click
    
    e.preventDefault();
    isDragging = false;
    
    startX = e.clientX;
    startY = e.clientY;
    currentX = startX;
    currentY = startY;
    
    // Get current computed style
    const rect = el.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;

    // Temporarily disable transitions for smooth dragging
    el.style.transition = 'none';
    
    // Convert right/bottom to left/top for consistent dragging
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    el.style.left = initialLeft + 'px';
    el.style.top = initialTop + 'px';

    document.addEventListener('pointermove', drag);
    document.addEventListener('pointerup', dragEnd);
    document.addEventListener('pointercancel', dragEnd);
  }

  function updatePosition() {
    if (!isDragging) return;
    
    const dx = currentX - startX;
    const dy = currentY - startY;
    
    let newLeft = initialLeft + dx;
    let newTop = initialTop + dy;
    
    // Keep within window bounds
    newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - el.offsetWidth));
    newTop = Math.max(0, Math.min(newTop, window.innerHeight - el.offsetHeight));
    
    el.style.left = newLeft + 'px';
    el.style.top = newTop + 'px';
    
    animationFrameId = requestAnimationFrame(updatePosition);
  }

  function drag(e) {
    currentX = e.clientX;
    currentY = e.clientY;
    
    const dx = currentX - startX;
    const dy = currentY - startY;
    
    // Only consider it a drag if moved more than 3 pixels
    if (!isDragging && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) {
      isDragging = true;
      animationFrameId = requestAnimationFrame(updatePosition);
    }
  }

  function dragEnd(e) {
    document.removeEventListener('pointermove', drag);
    document.removeEventListener('pointerup', dragEnd);
    document.removeEventListener('pointercancel', dragEnd);
    
    if (animationFrameId) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }
    
    // Restore transition
    el.style.transition = 'all 0.2s ease';
    
    if (isDragging) {
      // Prevent click event from firing after a drag
      const preventClick = (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        el.removeEventListener('click', preventClick, true);
      };
      el.addEventListener('click', preventClick, true);
      
      // Reset isDragging after a short delay so normal clicks work again
      setTimeout(() => {
        isDragging = false;
      }, 50);
    }
  }
}

// Create and inject the AI Reply button
function createAIButton() {
  const btn = document.createElement('button');
  btn.id = 'wa-ai-reply-btn';
  btn.className = 'wa-ai-pulse';
  btn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> AI Reply';
  
  chrome.storage.sync.get({ btnOpacity: 100, btnTheme: 'gradient' }, (data) => {
    const opacity = data.btnOpacity / 100;
    const theme = data.btnTheme || 'gradient';
    
    let themeStyles = '';
    
    switch(theme) {
      case 'glass':
        themeStyles = `
          background: rgba(255, 255, 255, ${opacity * 0.15});
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
        `;
        break;
      case 'neon':
        themeStyles = `
          background: rgba(0, 0, 0, ${opacity});
          color: #00ffcc;
          border: 1px solid #00ffcc;
          box-shadow: 0 0 10px rgba(0, 255, 204, 0.3), inset 0 0 10px rgba(0, 255, 204, 0.1);
        `;
        break;
      case 'minimal':
        themeStyles = `
          background: rgba(255, 255, 255, ${opacity});
          color: #000000;
          border: 1px solid rgba(0, 0, 0, 0.1);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        `;
        break;
      case '3d':
        themeStyles = `
          background: rgba(0, 0, 0, ${opacity});
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 4px 0 rgba(255, 255, 255, 0.2), 0 8px 16px rgba(0,0,0,0.4);
          transform: translateY(0);
        `;
        break;
      case 'cyberpunk':
        themeStyles = `
          background: rgba(252, 238, 10, ${opacity});
          color: #000000;
          border: 2px solid #000000;
          box-shadow: 4px 4px 0 #000000;
          border-radius: 0;
        `;
        break;
      case 'material':
        themeStyles = `
          background: rgba(255, 255, 255, ${opacity});
          color: #1a73e8;
          border: none;
          box-shadow: 0 3px 5px -1px rgba(0,0,0,0.2), 0 6px 10px 0 rgba(0,0,0,0.14), 0 1px 18px 0 rgba(0,0,0,0.12);
        `;
        break;
      case 'holographic':
        themeStyles = `
          background: linear-gradient(135deg, rgba(255,0,204,${opacity}), rgba(51,51,255,${opacity}), rgba(0,255,204,${opacity}));
          background-size: 200% 200%;
          color: #ffffff;
          border: 1px solid rgba(255,255,255,0.5);
          box-shadow: 0 0 15px rgba(255, 0, 204, 0.5), 0 0 20px rgba(0, 255, 204, 0.5);
          animation: holoGradient 3s ease infinite;
        `;
        break;
      case 'gradient':
      default:
        themeStyles = `
          background: linear-gradient(135deg, rgba(17, 24, 39, ${opacity}), rgba(0, 0, 0, ${opacity}));
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(12px);
        `;
        break;
    }

    btn.style.cssText = `
      position: fixed;
      right: 24px;
      bottom: 84px;
      z-index: 9999;
      border-radius: 9999px;
      padding: 10px 20px;
      font-size: 14px;
      font-weight: 500;
      cursor: grab;
      display: none;
      align-items: center;
      gap: 8px;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
      letter-spacing: -0.01em;
      ${themeStyles}
    `;
    
    btn.onmouseover = () => {
      if (theme === '3d') {
        btn.style.transform = 'translateY(2px)';
        btn.style.boxShadow = '0 2px 0 rgba(255, 255, 255, 0.2), 0 4px 8px rgba(0,0,0,0.4)';
      } else if (theme === 'gradient') {
        btn.style.transform = 'translateY(-2px)';
        btn.style.boxShadow = '0 12px 24px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2)';
        btn.style.background = `linear-gradient(135deg, rgba(31, 41, 55, ${opacity}), rgba(17, 24, 39, ${opacity}))`;
      } else if (theme === 'neon') {
        btn.style.boxShadow = '0 0 15px rgba(0, 255, 204, 0.5), inset 0 0 15px rgba(0, 255, 204, 0.2)';
        btn.style.transform = 'translateY(-1px)';
      } else if (theme === 'glass') {
        btn.style.background = `rgba(255, 255, 255, ${opacity * 0.25})`;
        btn.style.boxShadow = '0 12px 40px 0 rgba(0, 0, 0, 0.3)';
        btn.style.transform = 'translateY(-1px)';
      } else if (theme === 'minimal') {
        btn.style.background = `rgba(249, 250, 251, ${opacity})`;
        btn.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.12)';
        btn.style.transform = 'translateY(-1px)';
      } else if (theme === 'cyberpunk') {
        btn.style.background = `rgba(255, 255, 255, ${opacity})`;
        btn.style.boxShadow = '6px 6px 0 #000000';
        btn.style.transform = 'translate(-2px, -2px)';
      } else if (theme === 'material') {
        btn.style.boxShadow = '0 5px 5px -3px rgba(0,0,0,0.2), 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12)';
        btn.style.transform = 'translateY(-2px)';
      } else if (theme === 'holographic') {
        btn.style.boxShadow = '0 0 25px rgba(255, 0, 204, 0.7), 0 0 30px rgba(0, 255, 204, 0.7)';
        btn.style.transform = 'translateY(-1px) scale(1.02)';
      }
    };
    
    btn.onmouseout = () => {
      if (theme === '3d') {
        btn.style.transform = 'translateY(0)';
        btn.style.boxShadow = '0 4px 0 rgba(255, 255, 255, 0.2), 0 8px 16px rgba(0,0,0,0.4)';
      } else if (theme === 'gradient') {
        btn.style.transform = 'translateY(0)';
        btn.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
        btn.style.background = `linear-gradient(135deg, rgba(17, 24, 39, ${opacity}), rgba(0, 0, 0, ${opacity}))`;
      } else if (theme === 'neon') {
        btn.style.boxShadow = '0 0 10px rgba(0, 255, 204, 0.3), inset 0 0 10px rgba(0, 255, 204, 0.1)';
        btn.style.transform = 'translateY(0)';
      } else if (theme === 'glass') {
        btn.style.background = `rgba(255, 255, 255, ${opacity * 0.15})`;
        btn.style.boxShadow = '0 8px 32px 0 rgba(0, 0, 0, 0.2)';
        btn.style.transform = 'translateY(0)';
      } else if (theme === 'minimal') {
        btn.style.background = `rgba(255, 255, 255, ${opacity})`;
        btn.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
        btn.style.transform = 'translateY(0)';
      } else if (theme === 'cyberpunk') {
        btn.style.background = `rgba(252, 238, 10, ${opacity})`;
        btn.style.boxShadow = '4px 4px 0 #000000';
        btn.style.transform = 'translate(0, 0)';
      } else if (theme === 'material') {
        btn.style.boxShadow = '0 3px 5px -1px rgba(0,0,0,0.2), 0 6px 10px 0 rgba(0,0,0,0.14), 0 1px 18px 0 rgba(0,0,0,0.12)';
        btn.style.transform = 'translateY(0)';
      } else if (theme === 'holographic') {
        btn.style.boxShadow = '0 0 15px rgba(255, 0, 204, 0.5), 0 0 20px rgba(0, 255, 204, 0.5)';
        btn.style.transform = 'translateY(0) scale(1)';
      }
    };
  });

  btn.addEventListener('click', handleGenerateReply);
  makeDraggable(btn);
  return btn;
}

// Extract chat history based on platform
function getChatContext(platform) {
  const messages = [];
  
  if (platform === PLATFORMS.WHATSAPP) {
    const rows = document.querySelectorAll('div[role="row"]');
    const recentRows = Array.from(rows).slice(-20);
    
    recentRows.forEach(row => {
      const isOut = row.querySelectorAll('div.message-out').length > 0 || 
                    row.innerHTML.includes('message-out') ||
                    (row.getAttribute('data-id') && row.getAttribute('data-id').startsWith('true_'));
      
      let text = '';
      
      // WhatsApp text is usually inside a span within .selectable-text
      const selectableSpans = row.querySelectorAll('.selectable-text span.selectable-text, .selectable-text span[dir="ltr"], .selectable-text span[dir="rtl"]');
      if (selectableSpans.length > 0) {
        text = Array.from(selectableSpans).map(s => s.innerText).join(' ');
      } else {
        const selectable = row.querySelector('.selectable-text');
        if (selectable) {
          text = selectable.innerText;
        }
      }
      
      // Fallback for some WhatsApp versions
      if (!text || !text.trim()) {
        const copyable = row.querySelector('.copyable-text span');
        if (copyable) text = copyable.innerText;
      }
      
      // Check for images
      const imgs = row.querySelectorAll('img');
      let hasImage = false;
      imgs.forEach(img => {
        if (img.src && img.src.startsWith('blob:')) {
          hasImage = true;
        }
      });
      if (hasImage) {
        text += ' [User attached an image/document]';
      }
      
      if (text && text.trim()) {
        // Ignore messages that are just timestamps
        if (!/^\d{1,2}:\d{2}$/.test(text.trim())) {
          messages.push({ role: isOut ? 'assistant' : 'user', content: text.trim() });
        }
      }
    });
  } 
  else if (platform === PLATFORMS.MESSENGER) {
    const rows = document.querySelectorAll('div[role="row"]');
    const recentRows = Array.from(rows).slice(-20);
    recentRows.forEach(row => {
      const textDiv = row.querySelector('div[dir="auto"]');
      if (textDiv && textDiv.innerText.trim()) {
        const rect = textDiv.getBoundingClientRect();
        const isOut = rect.left > window.innerWidth / 2;
        messages.push({ role: isOut ? 'assistant' : 'user', content: textDiv.innerText.trim() });
      }
    });
  }
  
  return messages;
}

// Insert text into input box based on platform
function insertTextIntoInput(text, platform) {
  let inputEl = null;
  
  if (platform === PLATFORMS.WHATSAPP) {
    // Specifically target the message compose box, avoiding the search box
    // The main chat input is usually inside #main footer
    inputEl = document.querySelector('#main footer div[contenteditable="true"][data-tab="10"]') || 
              document.querySelector('#main footer div[contenteditable="true"]');
  } 
  else if (platform === PLATFORMS.MESSENGER) {
    inputEl = document.querySelector('div[contenteditable="true"][role="textbox"]') || 
              document.querySelector('div[aria-label="Message"][contenteditable="true"]') ||
              document.querySelector('div[aria-label="Message"]');
  }

  if (!inputEl) {
    console.error("Could not find input box for platform: " + platform);
    return false;
  }

  inputEl.focus();
  
  setTimeout(() => {
    document.execCommand('insertText', false, text);
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
  }, 100);
  
  return true;
}

// Check if chat is active
function isChatActive(platform) {
  if (platform === PLATFORMS.WHATSAPP) {
    // Specifically target the message compose box area
    return !!document.querySelector('#main footer div[contenteditable="true"]') || document.querySelectorAll('div[role="row"]').length > 0;
  }
  else if (platform === PLATFORMS.MESSENGER) {
    return !!document.querySelector('div[contenteditable="true"][role="textbox"]') || 
           !!document.querySelector('div[aria-label="Message"][contenteditable="true"]') ||
           !!document.querySelector('div[aria-label="Message"]');
  }
  return false;
}

// Handle button click
function handleGenerateReply(e) {
  e.preventDefault();
  e.stopPropagation();
  
  const platform = detectPlatform();
  if (!platform) return;

  const btn = e.currentTarget;
  const originalHTML = btn.innerHTML;
  
  // Typing indicator animation
  btn.innerHTML = `
    <style>
      .wa-ai-typing { display: flex; align-items: center; gap: 4px; height: 20px; }
      .wa-ai-dot { width: 4px; height: 4px; background: currentColor; border-radius: 50%; animation: wa-ai-bounce 1.4s infinite ease-in-out both; }
      .wa-ai-dot:nth-child(1) { animation-delay: -0.32s; }
      .wa-ai-dot:nth-child(2) { animation-delay: -0.16s; }
      @keyframes wa-ai-bounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
    </style>
    <div class="wa-ai-typing">
      <div class="wa-ai-dot"></div>
      <div class="wa-ai-dot"></div>
      <div class="wa-ai-dot"></div>
    </div>
  `;
  
  btn.disabled = true;
  btn.style.cursor = 'wait';
  btn.style.boxShadow = '0 0 25px #6366f1, 0 0 50px rgba(99, 102, 241, 0.5)';
  btn.style.transform = 'scale(0.98)';

  showToast('AI 正在思考回复...', 'loading', 0);

  const context = getChatContext(platform);
  
  if (context.length === 0) {
    showToast('未找到聊天记录，请打开一个包含消息的聊天窗口。', 'error');
    resetButton(btn, originalHTML);
    return;
  }

  chrome.runtime.sendMessage({ action: 'generateReply', context: context }, (response) => {
    resetButton(btn, originalHTML);
    
    if (chrome.runtime.lastError) {
      showToast('插件连接错误: ' + chrome.runtime.lastError.message + ' (请刷新页面重试)', 'error', 5000);
      return;
    }
    
    if (response && response.success) {
      const success = insertTextIntoInput(response.reply, platform);
      if (success) {
        showToast('✅ 回复已生成并填入输入框！', 'success');
      } else {
        showToast('⚠️ 回复已生成，但无法自动填充，请手动复制。', 'error');
        console.log('Generated Reply:', response.reply);
      }
    } else {
      let errorMsg = response?.error || '未知错误，请检查 API 设置。';
      // Rationalize error messages
      if (errorMsg.includes('Failed to fetch') || errorMsg.includes('NetworkError')) {
        errorMsg = '网络请求失败，请检查您的网络连接或 API 地址是否正确。';
      } else if (errorMsg.includes('401')) {
        errorMsg = 'API 密钥无效或未授权 (HTTP 401)，请检查您的 API Key。';
      } else if (errorMsg.includes('404')) {
        errorMsg = 'API 地址不存在 (HTTP 404)，请检查 API URL 是否正确。';
      } else if (errorMsg.includes('429')) {
        errorMsg = '请求过于频繁或额度耗尽 (HTTP 429)，请稍后再试或检查账户余额。';
      } else if (errorMsg.includes('500') || errorMsg.includes('502') || errorMsg.includes('503')) {
        errorMsg = 'AI 服务端错误 (' + errorMsg.match(/\d{3}/)?.[0] + ')，请稍后再试。';
      }
      showToast('❌ AI 回复出错: ' + errorMsg, 'error', 6000);
    }
  });
}

function resetButton(btn, originalHTML) {
  btn.innerHTML = originalHTML;
  btn.disabled = false;
  btn.style.cursor = 'grab';
  btn.style.transform = '';
  // Re-apply theme-specific box shadow by triggering mouseout
  btn.dispatchEvent(new Event('mouseout'));
}

function updateButtonVisibility() {
  const btn = document.getElementById('wa-ai-reply-btn');
  if (!btn) return;
  
  const platform = detectPlatform();
  if (isChatActive(platform)) {
    btn.style.display = 'flex';
  } else {
    btn.style.display = 'none';
  }
}

// Observe DOM changes to inject button and update visibility
const observer = new MutationObserver(() => {
  if (!document.getElementById('wa-ai-reply-btn')) {
    injectFonts();
    document.body.appendChild(createAIButton());
  }
  updateButtonVisibility();
});

// Start observing
observer.observe(document.body, { childList: true, subtree: true });

// Initial check
setTimeout(() => {
  if (!document.getElementById('wa-ai-reply-btn')) {
    injectFonts();
    document.body.appendChild(createAIButton());
  }
  updateButtonVisibility();
}, 2000);

// Shortcut listener
let currentShortcut = '';
chrome.storage.sync.get({ shortcut: 'Alt + 1' }, (data) => {
  currentShortcut = data.shortcut;
});
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync' && changes.shortcut) {
    currentShortcut = changes.shortcut.newValue;
  }
  if (namespace === 'sync' && (changes.btnTheme || changes.btnOpacity)) {
    // Recreate button if theme or opacity changes
    const oldBtn = document.getElementById('wa-ai-reply-btn');
    if (oldBtn) oldBtn.remove();
    document.body.appendChild(createAIButton());
  }
});

document.addEventListener('keydown', (e) => {
  if (!currentShortcut) return;
  
  const keys = [];
  if (e.ctrlKey) keys.push('Ctrl');
  if (e.altKey) keys.push('Alt');
  if (e.shiftKey) keys.push('Shift');
  if (e.metaKey) keys.push('Cmd');
  if (e.key !== 'Control' && e.key !== 'Alt' && e.key !== 'Shift' && e.key !== 'Meta') {
    keys.push(e.key.toUpperCase());
  }
  const pressed = keys.join(' + ');
  
  if (pressed === currentShortcut && keys.length > 0) {
    e.preventDefault();
    const btn = document.getElementById('wa-ai-reply-btn');
    if (btn && btn.style.display !== 'none' && !btn.disabled) {
      btn.click();
    }
  }
});
