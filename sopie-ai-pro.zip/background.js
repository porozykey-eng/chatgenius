chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'generateReply') {
    chrome.storage.sync.get(['provider', 'apiUrl', 'apiKey', 'modelName', 'personas', 'activePersonaId', 'tone', 'replyLength', 'faqData'], async (data) => {
      try {
        if (!data.apiKey) {
          throw new Error('API Key not configured. Please open settings.');
        }

        let systemInstruction = 'You are a helpful assistant.';
        
        if (data.personas && data.activePersonaId) {
          const activePersona = data.personas.find(p => p.id === data.activePersonaId);
          if (activePersona && activePersona.prompt) {
            systemInstruction = activePersona.prompt;
          }
        }

        if (data.tone && data.tone !== 'auto') {
          systemInstruction += '\n\nPlease reply with a ' + data.tone + ' tone.';
        }

        systemInstruction += '\n\nCRITICAL: Detect the language of the last message and reply in that SAME language automatically unless specified otherwise.';

        if (data.replyLength && data.replyLength !== 'auto') {
          const lengthMap = {
            short: '1-2 sentences',
            medium: '2-4 sentences',
            long: 'detailed'
          };
          systemInstruction += '\n\nPlease provide a ' + lengthMap[data.replyLength] + ' response.';
        }

        if (data.faqData && data.faqData.length > 0) {
          systemInstruction += '\n\nKnowledge Base (FAQ):\n' + data.faqData.map(f => 'Q: ' + f.q + '\nA: ' + f.a).join('\n---\n');
          systemInstruction += '\n\nPlease use the above information to answer questions if relevant, but keep the conversation natural.';
        }

        const messages = [
          { role: 'system', content: systemInstruction },
          ...request.context
        ];

        if (request.context.length === 0) {
          messages.push({ role: 'user', content: 'Hello! Please introduce yourself.' });
        }

        let apiUrl = (data.apiUrl || 'https://api.openai.com/v1/chat/completions').replace(/\/+$/, '');
        if (!apiUrl.endsWith('/chat/completions') && !apiUrl.endsWith('/messages')) {
          apiUrl += '/chat/completions';
        }

        const bodyData = {
          model: data.modelName || 'gpt-3.5-turbo',
          messages: messages
        };

        if (!bodyData.model.startsWith('o1') && !bodyData.model.startsWith('o3')) {
          bodyData.temperature = 0.7;
        }

        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${data.apiKey.trim()}`
          },
          body: JSON.stringify(bodyData)
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error?.message || 'API request failed');
        }

        const result = await response.json();
        let reply = 'No reply generated.';
        if (result.choices && result.choices.length > 0) {
          reply = result.choices[0].message?.content || result.choices[0].text || '';
        } else if (result.content && result.content.length > 0) {
          reply = result.content[0].text || '';
        } else if (result.message && result.message.content) {
          reply = result.message.content;
        }
        reply = reply.trim();
        sendResponse({ success: true, reply });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    });
    return true;
  }
});