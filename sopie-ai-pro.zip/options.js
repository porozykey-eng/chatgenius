const I18N = {
  en: {
    title: 'AI Auto-Reply Settings',
    instructionsTitle: 'User Guide',
    close: 'Got it',
    instructionsContent: '1. Configure API: Click the extension icon in the toolbar to set your AI Provider and API Key.<br><br>2. Set Persona: Define your custom persona below (e.g., Sales Manager, Tech Support) so the AI knows how to act.<br><br>3. Use in Chat: Open WhatsApp or Messenger web. A floating "AI Reply" button will appear. Click it (or use the shortcut) to generate a context-aware reply based on the recent chat history.',
    proTitle: 'Elite Pro Intelligence',
    proPrice: '$9.90 / Year',
    proUpgradeBtn: 'Upgrade to Elite Pro',
    proFeatures: [
      { title: 'Unlimited Personas', desc: 'Create as many AI identities as you need.', icon: '🎭' },
      { title: 'Knowledge Base', desc: 'Upload PDFs or sync FAQs for smarter replies.', icon: '📚' },
      { title: 'Priority Models', desc: 'Access to GPT-4o and Gemini 1.5 Pro.', icon: '⚡' },
      { title: 'Cloud Sync', desc: 'Sync settings across all your devices.', icon: '☁️' }
    ],
    personaSettings: 'Custom Personas',
    personaHelp: 'Create custom personas. Select one to use as the active persona.',
    addPersona: '+ Add Persona',
    personaName: 'Persona Name',
    personaPrompt: 'System Prompt',
    replySettings: 'Reply Preferences',
    tone: 'Reply Tone',
    toneAuto: 'Auto (Context-based)',
    tonePro: 'Professional',
    toneFriendly: 'Friendly & Warm',
    toneEmpathetic: 'Empathetic',
    toneDirect: 'Direct & Concise',
    replyLength: 'Reply Length',
    lenAuto: 'Auto',
    lenShort: 'Short (1-2 sentences)',
    lenMedium: 'Medium (2-4 sentences)',
    lenLong: 'Detailed',
    faq: 'Knowledge Base / FAQ',
    addFaq: '+ Add Q&A',
    faqHelp: 'AI will naturally weave this info into replies.',
    uiSettings: 'UI & Interaction',
    shortcut: 'Shortcut Key',
    shortcutHelp: 'Click and press keys. Press Backspace to clear.',
    btnTheme: 'Floating Button Theme',
    themeGradient: 'Gradient Glow',
    themeGlass: 'Glassmorphism',
    themeNeon: 'Cyber Neon',
    themeMinimal: 'Minimalist',
    theme3D: '3D Pop',
    themeCyberpunk: 'Cyberpunk',
    themeMaterial: 'Material Design',
    themeHolographic: 'Holographic',
    btnOpacity: 'Button Opacity',
    save: 'Save Settings',
    saved: 'Saved Successfully!',
    error: 'Error saving settings',
    livePreview: 'Live Persona Preview',
    previewHelp: 'Test your active persona in real-time.',
    statReplies: 'Total Replies',
    statTimeSaved: 'Time Saved',
    statStatus: 'System Status'
  },
  zh: {
    title: 'AI 自动回复设置',
    instructionsTitle: '使用说明',
    close: '知道了',
    instructionsContent: '1. 配置 API：点击浏览器工具栏中的插件图标，设置您的 AI 提供商和 API Key。<br><br>2. 设置人设：在下方创建并选择您的专属角色（例如：销售经理、技术支持），让 AI 知道如何回复客户。<br><br>3. 在聊天中使用：打开 WhatsApp 或 Messenger 网页版。聊天窗口旁会出现一个“AI Reply”悬浮按钮。点击它（或使用快捷键）即可根据最近的聊天记录生成回复。',
    proTitle: 'Elite Pro 智能版',
    proPrice: '$9.90 / 年',
    proUpgradeBtn: '立即升级至 Elite Pro',
    proFeatures: [
      { title: '无限角色模板', desc: '随心所欲创建多种 AI 身份。', icon: '🎭' },
      { title: '超大知识库', desc: '支持上传文档或同步 FAQ。', icon: '📚' },
      { title: '顶级模型', desc: '优先访问 GPT-4o 和 Gemini 1.5 Pro。', icon: '⚡' },
      { title: '云端同步', desc: '多设备同步您的所有设置。', icon: '☁️' }
    ],
    personaSettings: '自定义角色',
    personaHelp: '创建自定义角色。选择一个作为当前激活的角色。',
    addPersona: '+ 添加角色',
    personaName: '角色名称',
    personaPrompt: '系统提示词 (Prompt)',
    replySettings: '回复偏好',
    tone: '回复语气',
    toneAuto: '自动 (根据语境)',
    tonePro: '专业严谨',
    toneFriendly: '热情友好',
    toneEmpathetic: '共情理解',
    toneDirect: '直接干练',
    replyLength: '回复长度',
    lenAuto: '自动',
    lenShort: '简短 (1-2句话)',
    lenMedium: '适中 (2-4句话)',
    lenLong: '详细',
    faq: '常用问答 / 知识库 (FAQ)',
    addFaq: '+ 添加问答',
    faqHelp: '输入常见问题和答案，AI 会根据客户问题自然地融入这些信息，而不是生硬复制。',
    uiSettings: '界面与交互',
    shortcut: '快捷键',
    shortcutHelp: '点击后按下组合键。按 Backspace 清除。',
    btnTheme: '悬浮按钮主题',
    themeGradient: '渐变发光',
    themeGlass: '毛玻璃',
    themeNeon: '赛博霓虹',
    themeMinimal: '极简主义',
    theme3D: '3D 立体',
    themeCyberpunk: '赛博朋克',
    themeMaterial: '质感设计',
    themeHolographic: '全息幻彩',
    btnOpacity: '悬浮按钮透明度',
    save: '保存设置',
    saved: '保存成功！',
    error: '保存失败',
    livePreview: '实时人设预览',
    previewHelp: '实时测试您当前选择的角色回复效果。',
    statReplies: '累计回复',
    statTimeSaved: '节省时间',
    statStatus: '系统状态'
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const personaList = document.getElementById('personaList');
  const addPersonaBtn = document.getElementById('addPersonaBtn');
  const shortcutInput = document.getElementById('shortcut');
  const toneSelect = document.getElementById('tone');
  const replyLengthSelect = document.getElementById('replyLength');
  const faqList = document.getElementById('faqList');
  const addFaqBtn = document.getElementById('addFaqBtn');
  const btnThemeSelect = document.getElementById('btnTheme');
  const btnPreview = document.getElementById('btnPreview');
  const btnOpacityInput = document.getElementById('btnOpacity');
  const opacityVal = document.getElementById('opacityVal');
  const saveBtn = document.getElementById('saveBtn');
  const themeToggle = document.getElementById('themeToggle');
  const langToggle = document.getElementById('langToggle');
  const helpBtn = document.getElementById('helpBtn');
  const proFeaturesContainer = document.getElementById('proFeatures');
  const previewChat = document.getElementById('previewChat');
  const previewInput = document.getElementById('previewInput');
  const previewSendBtn = document.getElementById('previewSendBtn');
  
  function renderProFeatures() {
    proFeaturesContainer.innerHTML = '';
    const features = I18N[currentLang].proFeatures;
    features.forEach(f => {
      const card = document.createElement('div');
      card.className = 'pro-feature-card';
      card.innerHTML = '<div style="font-size: 24px; margin-bottom: 12px;">' + f.icon + '</div>' +
                       '<h3>' + f.title + '</h3>' +
                       '<p>' + f.desc + '</p>';
      proFeaturesContainer.appendChild(card);
    });
  }

  function addPreviewMessage(text, type) {
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble ' + type;
    bubble.textContent = text;
    previewChat.appendChild(bubble);
    previewChat.scrollTop = previewChat.scrollHeight;
  }

  previewSendBtn.addEventListener('click', async () => {
    const text = previewInput.value.trim();
    if (!text) return;
    
    addPreviewMessage(text, 'user');
    previewInput.value = '';
    
    // Simulate AI thinking
    const thinkingBubble = document.createElement('div');
    thinkingBubble.className = 'chat-bubble ai';
    thinkingBubble.textContent = '...';
    previewChat.appendChild(thinkingBubble);
    
    setTimeout(() => {
      const activePersona = personas.find(p => p.id === activePersonaId) || { name: 'Default', prompt: 'Helpful assistant' };
      thinkingBubble.textContent = '[As ' + (activePersona.name || 'AI') + ']: I\'ve analyzed your message and based on my persona, I would reply in a ' + toneSelect.value + ' tone.';
    }, 1000);
  });

  if (helpBtn) {
    helpBtn.addEventListener('click', () => {
      const modal = document.getElementById('helpModal');
      if (modal) modal.style.display = 'flex';
    });
  }
  
  const closeHelpBtn = document.getElementById('closeHelpBtn');
  if (closeHelpBtn) {
    closeHelpBtn.addEventListener('click', () => {
      const modal = document.getElementById('helpModal');
      if (modal) modal.style.display = 'none';
    });
  }

  let currentLang = 'zh';
  let currentTheme = 'dark';
  let faqData = [];
  let personas = [];
  let activePersonaId = null;

  function generateId() {
    return Math.random().toString(36).substr(2, 9);
  }

  function renderPersonas() {
    personaList.innerHTML = '';
    personas.forEach((persona, index) => {
      const div = document.createElement('div');
      div.className = 'persona-item';
      
      const header = document.createElement('div');
      header.className = 'persona-header';
      
      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'activePersona';
      radio.className = 'persona-radio';
      radio.checked = persona.id === activePersonaId;
      radio.onchange = () => { activePersonaId = persona.id; };
      
      const nameInput = document.createElement('input');
      nameInput.type = 'text';
      nameInput.className = 'persona-name';
      nameInput.placeholder = currentLang === 'zh' ? '角色名称' : 'Persona Name';
      nameInput.value = persona.name;
      nameInput.onchange = (e) => { personas[index].name = e.target.value; };
      
      const delBtn = document.createElement('button');
      delBtn.innerHTML = '×';
      delBtn.className = 'persona-delete';
      delBtn.title = currentLang === 'zh' ? '删除角色' : 'Delete Persona';
      delBtn.onclick = () => {
        personas.splice(index, 1);
        if (activePersonaId === persona.id) {
          activePersonaId = personas.length > 0 ? personas[0].id : null;
        }
        renderPersonas();
      };
      
      header.appendChild(radio);
      header.appendChild(nameInput);
      header.appendChild(delBtn);
      
      const promptInput = document.createElement('textarea');
      promptInput.className = 'persona-prompt';
      promptInput.placeholder = currentLang === 'zh' ? '系统提示词 (Prompt)' : 'System Prompt';
      promptInput.value = persona.prompt;
      promptInput.onchange = (e) => { personas[index].prompt = e.target.value; };
      
      div.appendChild(header);
      div.appendChild(promptInput);
      personaList.appendChild(div);
    });
  }

  addPersonaBtn.addEventListener('click', () => {
    const newId = generateId();
    personas.push({ id: newId, name: '', prompt: '' });
    if (!activePersonaId) activePersonaId = newId;
    renderPersonas();
  });

  function renderFaq() {
    faqList.innerHTML = '';
    faqData.forEach((item, index) => {
      const div = document.createElement('div');
      div.className = 'faq-item';
      
      const qInput = document.createElement('input');
      qInput.placeholder = currentLang === 'zh' ? '问题 (Question)' : 'Question';
      qInput.value = item.q;
      qInput.onchange = (e) => { faqData[index].q = e.target.value; };
      
      const aInput = document.createElement('textarea');
      aInput.placeholder = currentLang === 'zh' ? '答案 (Answer)' : 'Answer';
      aInput.value = item.a;
      aInput.onchange = (e) => { faqData[index].a = e.target.value; };
      
      const delBtn = document.createElement('button');
      delBtn.textContent = '×';
      delBtn.className = 'faq-delete';
      delBtn.onclick = () => {
        faqData.splice(index, 1);
        renderFaq();
      };
      
      div.appendChild(qInput);
      div.appendChild(aInput);
      div.appendChild(delBtn);
      faqList.appendChild(div);
    });
  }

  addFaqBtn.addEventListener('click', () => {
    faqData.push({ q: '', a: '' });
    renderFaq();
  });

  shortcutInput.addEventListener('keydown', (e) => {
    e.preventDefault();
    if (e.key === 'Backspace' || e.key === 'Delete') {
      shortcutInput.value = '';
      return;
    }
    const keys = [];
    if (e.ctrlKey) keys.push('Ctrl');
    if (e.altKey) keys.push('Alt');
    if (e.shiftKey) keys.push('Shift');
    if (e.metaKey) keys.push('Cmd');
    if (e.key !== 'Control' && e.key !== 'Alt' && e.key !== 'Shift' && e.key !== 'Meta') {
      keys.push(e.key.toUpperCase());
    }
    if (keys.length > 0) {
      shortcutInput.value = keys.join(' + ');
    }
  });

  function applyI18n() {
    document.documentElement.lang = currentLang === 'zh' ? 'zh-CN' : 'en';
    langToggle.textContent = currentLang === 'zh' ? 'EN' : '中';
    
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (I18N[currentLang][key]) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.placeholder = I18N[currentLang][key];
        } else if (key === 'instructionsContent') {
          el.innerHTML = I18N[currentLang][key];
        } else if (key !== 'proFeatures') {
          el.textContent = I18N[currentLang][key];
        }
      }
    });
    renderPersonas();
    renderFaq();
    renderProFeatures();
  }

  function showToast(msg, isError = false) {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toastMsg');
    toastMsg.textContent = msg;
    toast.className = isError ? 'error show' : 'show';
    setTimeout(() => { toast.className = toast.className.replace('show', '').trim(); }, 2500);
  }

  btnOpacityInput.addEventListener('input', (e) => {
    opacityVal.textContent = e.target.value + '%';
    btnPreview.style.opacity = e.target.value / 100;
  });

  btnThemeSelect.addEventListener('change', (e) => {
    btnPreview.className = 'preview-btn theme-' + e.target.value;
  });

  themeToggle.addEventListener('click', () => {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    themeToggle.textContent = currentTheme === 'dark' ? '🌙' : '☀️';
    chrome.storage.sync.set({ theme: currentTheme });
  });

  langToggle.addEventListener('click', () => {
    currentLang = currentLang === 'zh' ? 'en' : 'zh';
    chrome.storage.sync.set({ lang: currentLang });
    applyI18n();
  });

  // Load saved settings
  chrome.storage.sync.get({
    personas: [
      { id: 'default', name: '默认角色模板 (Default Template)', prompt: '【填写指南】\n请在此处描述您的AI角色设定。例如：\n1. 您的身份（如：某公司的销售经理、客服代表）。\n2. 您的目标（如：解答客户疑问、引导客户下单、询问客户的具体需求）。\n3. 您的语气（如：专业、热情、幽默）。\n4. 必须包含的信息（如：产品类型、发货港口、数量等）。\n\n【示例】\n你是[XXX公司]的客户经理[你的名字]。请根据客户的消息上下文进行专业、礼貌的回复。在对话的适当阶段，你需要引导并询问客户对于[你的产品]的具体需求，例如：具体需要什么类型的？发往哪个港口？具体的吨位是多少？发货形式是CIF还是FOB等等。' }
    ],
    activePersonaId: 'default',
    shortcut: 'Alt + 1',
    tone: 'auto',
    replyLength: 'auto',
    faqData: [],
    btnTheme: 'gradient',
    btnOpacity: 100,
    theme: 'light',
    lang: 'zh'
  }, (data) => {
    currentTheme = data.theme;
    currentLang = data.lang;
    document.documentElement.setAttribute('data-theme', currentTheme);
    themeToggle.textContent = currentTheme === 'dark' ? '🌙' : '☀️';
    applyI18n();

    personas = data.personas || [];
    activePersonaId = data.activePersonaId;
    if (personas.length > 0 && !activePersonaId) {
      activePersonaId = personas[0].id;
    }
    renderPersonas();
    renderFaq();
    renderProFeatures();

    shortcutInput.value = data.shortcut;
    toneSelect.value = data.tone;
    replyLengthSelect.value = data.replyLength;
    faqData = data.faqData || [];
    renderFaq();

    btnThemeSelect.value = data.btnTheme;
    btnPreview.className = 'preview-btn theme-' + data.btnTheme;
    
    btnOpacityInput.value = data.btnOpacity;
    opacityVal.textContent = data.btnOpacity + '%';
    btnPreview.style.opacity = data.btnOpacity / 100;
  });

  const upgradeBtn = document.getElementById('upgradeBtn');
  upgradeBtn.addEventListener('click', () => {
    const msg = currentLang === 'zh' ? '正在跳转至支付页面...' : 'Redirecting to payment page...';
    showToast(msg);
    setTimeout(() => {
      alert(currentLang === 'zh' ? '演示版：支付功能即将上线！' : 'Demo: Payment feature coming soon!');
    }, 1000);
  });

  saveBtn.addEventListener('click', () => {
    const shortcut = shortcutInput.value.trim();
    const tone = toneSelect.value;
    const replyLength = replyLengthSelect.value;
    const btnTheme = btnThemeSelect.value;
    const btnOpacity = parseInt(btnOpacityInput.value, 10);

    // Filter out empty personas and FAQs
    const validPersonas = personas.filter(p => p.name.trim() || p.prompt.trim());
    const validFaq = faqData.filter(f => f.q.trim() || f.a.trim());

    saveBtn.disabled = true;
    saveBtn.style.opacity = '0.7';

    chrome.storage.sync.set({
      personas: validPersonas,
      activePersonaId,
      shortcut,
      tone,
      replyLength,
      faqData: validFaq,
      btnTheme,
      btnOpacity,
      theme: currentTheme,
      lang: currentLang
    }, () => {
      showToast(I18N[currentLang].saved);
      saveBtn.disabled = false;
      saveBtn.style.opacity = '1';
      // Re-render to show cleaned up lists
      personas = validPersonas;
      faqData = validFaq;
      renderPersonas();
      renderFaq();
    });
  });

  const proBtn = document.querySelector('.pro-btn');
  if (proBtn) {
    proBtn.addEventListener('click', () => {
      showToast(currentLang === 'zh' ? '即将推出支付宝付款功能，敬请期待！' : 'Alipay payment integration coming soon!');
    });
  }
});